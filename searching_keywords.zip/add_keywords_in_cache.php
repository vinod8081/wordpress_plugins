<?php
/**
 * Add the keywords in the cache.
 * @global type $wpdb
 */
function add_keyword_in_cache()
{
    if (!is_admin())
    {
        global $wpdb;

        $data = get_transient('keyword_list');

        if ($data === false)
        {
            $sql     = "select * from {$wpdb->prefix}common_searching_keywords";
            $results = $wpdb->get_results($sql);
            $keyword = array();
            foreach ($results as $result)
            {
                array_push($keyword, $result->searching_keyword);
            }
            $data = implode(',', $keyword);
            set_transient('keyword_list', $data, 3600 * 24);
        }

        //delete_transient('keyword_list');    
    }
}
add_action('init', 'add_keyword_in_cache');
/**
 * Get the keywords from the cache/db 
 * Return the ajax response
 * @global type $wpdb
 * @return type
 */
function get_searching_keywords()
{
    global $wpdb;

    $data = get_transient('keyword_list');

    if ($data === false)
    {
        $sql     = "select * from {$wpdb->prefix}common_searching_keywords";
        $results = $wpdb->get_results($sql);

        $keyword = array();
        foreach ($results as $result)
        {
            array_push($keyword, $result->searching_keyword);
        }
        $data = implode(',', $keyword);
        set_transient('keyword_list', $data, 3600 * 24);
    }
    return $data;
}
