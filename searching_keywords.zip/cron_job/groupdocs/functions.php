<?php

require_once __DIR__ . './vendor/autoload.php';

//###<i>This sample will show how to use <b>GetFile</b> method from Storage Api to download a file from GroupDocs Storage</i>
//Set variables and get POST data

function download_groupdoc_file($fileId) {
    $basePath = 'https://api.groupdocs.com/v2.0';
    $clientId = '8c28a479285fdcad';
    $privateKey = 'dfef24e00aeaed3ac53e6edc17f33b95';

    //###Check clientId, privateKey and file Id
    if (!isset($clientId) || !isset($privateKey) || !isset($fileId)) {
        return $error = 'Please enter all required parameters';        
        //F3::set('error', $error);
    } else {
        //###Create Signer, ApiClient and Storage Api objects
        //Create signer object
        $signer = new GroupDocsRequestSigner($privateKey);
        //Create apiClient object
        $apiClient = new APIClient($signer);
        //Create Storage Api object
        $storageApi = new StorageApi($apiClient);
        $docApi = new DocApi($apiClient);
        //Check if user entered base path
        if ($basePath == "") {
            //If base base is empty seting base path to prod server
            $basePath = 'https://api.groupdocs.com/v2.0';
        }
        //Set base path
        $storageApi->setBasePath($basePath);
        $docApi->setBasePath($basePath);
        //###Make a request to Doc API using clientId and file id
        //Obtaining all Metadata for file

        try {
            $docInfo = $docApi->GetDocumentMetadata($clientId, $fileId);
            //Selecting file names
            if ($docInfo->status == "Ok") {
                //Obtaining file name for entered file Id
                $name = $docInfo->result->last_view->document->name;
                $name = str_replace(array('"',"'"), '', $name);
            } else {

                throw new Exception($docInfo->error_message);
            }
            //###Make a request to Storage Api for dowloading file
            //Obtaining file stream of downloading file and definition of folder where to download file
            $outFileStream = FileStream::fromHttp(dirname(__FILE__) . '/temp', $name);
            //Downlaoding of file
            try {
                $file = $storageApi->GetFile($clientId, $fileId, $outFileStream);
                if ($file->downloadDirectory != "" && isset($file)) {

                    return array('path' => $outFileStream->downloadDirectory . '/' . $name, 'file_name' => $name);
                } else {

                    throw new Exception("Something wrong with entered data");
                }
            } catch (Exception $e) {
                echo $error = 'ERROR:2 ' . $e->getMessage() . "\n";
                return false;
            }
        } catch (Exception $e) {
            echo $error = 'ERROR:1 ' . $e->getMessage() . "\n";
            return false;
        }
    }
}
/*-
$fileId = '89ec0d1cf4e704c29be3d924a78f7cd274efe76685597b2fbd7c38a627eedef8';
$response = download_groupdoc_file($fileId);
echo $response['file_name'];
*/
//print_r($response);
//error_log(var_dump($response));
