<?php

/**
 * Added code to crawl the content of group docs
 * By VP
 * Ticke 5&6
 * https://barton.atlassian.net/browse/ACADEMY-5
 * https://barton.atlassian.net/browse/ACADEMY-6
 * @global type $post
 */

if (file_exists('../../../../wp-load.php')) {
    require_once '../../../../wp-load.php';
} elseif (file_exists('/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php')) {
    require_once '/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php';
}


// include file 
require_once 'class_crawl_content_file.php';
/**
 * Get the files which needs to be crawled.
 * @global type $wpdb
 * @return type
 */
function get_groupdocs_from_db() {
    global $wpdb;
    $your_tbl_name = $wpdb->prefix . 'groupdoc_file_log';
    $querystr = "SELECT post_id, groupdoc_name, id
                FROM {$your_tbl_name}
                WHERE groupdoc_crawl='0'
                LIMIT 25";
    $groupdoc_files = $wpdb->get_results($querystr, OBJECT);

    return $groupdoc_files;
}
/**
 * Update the status of crawled file in db
 * @global type $wpdb
 * @param type $id
 */
function update_groupdocs_from_db($id)
{
    global $wpdb;
    $your_tbl_name = $wpdb->prefix . 'groupdoc_file_log';
    $wpdb->update(
            $your_tbl_name, array(
        'groupdoc_crawl' => 1,
            ), array('id' => $id)
    );
}

function update_post_for_groupdoc() {

    $groupdoc_files = get_groupdocs_from_db();
    try{
    foreach ($groupdoc_files as $attachment) {
        $table_id = $attachment->id;
        $post_id = $attachment->post_id;
        echo $file_name = $attachment->groupdoc_name;

        $link = site_url() . '/wp-content/plugins/searching-keywords/cron_job/groupdocs/temp/' . $file_name;
        $file_extentsion = pathinfo($file_name, PATHINFO_EXTENSION);
        $content = get_content_file($link, $file_extentsion);
        $content = iconv('UTF-8', 'ASCII//IGNORE//TRANSLIT', $content);
        
        update_post_meta($post_id, ATTACHMENT_WITH_ARTICLE, wp_slash($content));
        
        // Call the method of the elastic search plugin
        // Reindexing for post with updated content
        do_action('save_post', $post_id);
        update_groupdocs_from_db($table_id);
    }
    }catch(Exception $e){
        echo $e->getMessage();
    }
}
update_post_for_groupdoc();




