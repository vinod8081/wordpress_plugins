<?php

/**
 * Added code to download the attachment from group docs
 * By VP
 * Ticke 5&6
 * https://barton.atlassian.net/browse/ACADEMY-5
 * https://barton.atlassian.net/browse/ACADEMY-6
 * @global type $post
 */
if (file_exists('../../../../wp-load.php')) {
    require_once '../../../../wp-load.php';
} elseif (file_exists('/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php')) {
    require_once '/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php';
}

/**
 * Script to get the content of the groupdoc files
 */
require_once 'groupdocs/functions.php';
/**
 * Code to download the groupdoc files
 * @global type $wpdb
 */
function getGroupDocFiles() {

    createTableGroupDoc();

    global $wpdb;
    $your_tbl_name = $wpdb->prefix . 'posts';
    $groupdoc_file_log = $wpdb->prefix . 'groupdoc_file_log';
    $groupdoc_files = $wpdb->get_results(
            "SELECT ID,post_content"
            . " FROM {$your_tbl_name}"
            . " WHERE `post_content` REGEXP '.*grpdocsview'"
            . " AND post_status = 'publish' "
            . " AND (post_type = 'post' OR post_type = 'page')"
            . " AND ID NOT IN(SELECT post_id from {$groupdoc_file_log}) LIMIT 10"
    );

    $query = '';
    foreach ($groupdoc_files as $each_post) {
        echo $post_id = $each_post->ID;
        $post_content = $each_post->post_content;

        $regexp = 'grpdocsview\s*file\s*=\s*"(.*)"';
        if (preg_match_all("/$regexp/siU", $post_content, $matches, PREG_SET_ORDER)) {
            $content = '';

            $file_id = $matches[0][1];
            $response = download_groupdoc_file($file_id);
            if (!is_array($response)) {
                echo $file_name = 'not found';
                $query .= "(NULL, '{$post_id}','{$file_id}', '{$file_name}', '1', CURRENT_TIMESTAMP),";
                continue;
            }
            $file_name = $response['file_name'];
            $query .= "(NULL, '{$post_id}','{$file_id}', '{$file_name}', '0', CURRENT_TIMESTAMP),";
        }
    }
    $sql = "INSERT INTO {$groupdoc_file_log} (`id`,`post_id`, `groupdoc_id`, `groupdoc_name`, `groupdoc_crawl`, `updated_at`) VALUES " . $query;
    $sql = rtrim($sql, ',');
    $wpdb->query($sql);
}

function createTableGroupDoc() {
    global $wpdb;
    $your_tbl_name = $wpdb->prefix . 'groupdoc_file_log';
    $sql = "CREATE TABLE IF NOT EXISTS " . $your_tbl_name . " (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `post_id` int(11) NOT NULL,
  `groupdoc_id` varchar(255) NOT NULL,
  `groupdoc_name` varchar(255) NOT NULL,
  `groupdoc_crawl` enum('1','0') NOT NULL DEFAULT '0',
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=latin1;";

    $wpdb->query($sql);
}

getGroupDocFiles();
