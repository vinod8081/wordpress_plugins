<?php
/**
 * Added code to get links of article which have groupdocs file
 * By VP
 * Ticke 5&6
 * https://barton.atlassian.net/browse/ACADEMY-5
 * https://barton.atlassian.net/browse/ACADEMY-6
 * @global type $post
 */
if (file_exists('../../../../wp-load.php')) {
    require_once '../../../../wp-load.php';
} elseif (file_exists('/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php')) {
    require_once '/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php';
}



function getLinksOfArticles() {

    global $wpdb;    
    $groupdoc_file_log = $wpdb->prefix . 'groupdoc_file_log';
    $groupdoc_files = $wpdb->get_results(
                        "SELECT post_id FROM {$groupdoc_file_log} WHERE groupdoc_name LIKE '%not found%'"
    );

    $query = '';
    foreach ($groupdoc_files as $each_post) {
         $post_id = $each_post->post_id;
         echo get_the_title($post_id);
         echo ":  ";
         echo $post_url = get_permalink($post_id);
         echo "\n";
    }
    
}
getLinksOfArticles();