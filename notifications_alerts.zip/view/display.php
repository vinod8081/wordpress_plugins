<?php

/**
 * Adds a box to the main column on the Page add/edit screens.
 */
function notifications_alerts_add_meta_box()
{

    add_meta_box('send_mail_to_users_radio', 'Do you want to notify the users', 'notifications_alerts_html_for_radio_buttons_callback', 'page', 'normal');
    //you can change the 4th paramter i.e. post to custom post type name, if you want it for something else
}

add_action('add_meta_boxes', 'notifications_alerts_add_meta_box');

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function notifications_alerts_html_for_radio_buttons_callback($post)
{

    // Add an nonce field so we can check for it later.
    wp_nonce_field('notifications_alerts_add_meta_box', 'notifications_alerts_nonce');
    //wp_nonce_field( basename( __FILE__ ), 'prfx_nonce' );

    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    //$value = get_post_meta( $post->ID, 'my_key', true ); //my_key is a meta_key. Change it to whatever you want
    //<label for="wdm_new_field"><?php _e( "Choose value:", 'choose_value' ); </label>
    ?>
    <div id="notifications_alerts_radio_buttons">
        <input type="radio" name="send_mail_to_users"  value="1"/>Yes<br>
        <input type="radio" name="send_mail_to_users" value="0" <?php checked(0, '0'); ?>/>No
        <input type='hidden' id='post_id' name='post_id' value="<?php echo $post->ID; ?>"/>
    </div>    
    <div id="notifications_alerts_email_list" style="width: 100%;padding-bottom: 20px;">        
    </div>
    <div id="notifications_alerts_div">
        <ul class="tabs">
            <li class="hide litab1"><a href="#tab1">0-6 Months <span>(0)</span></a></li>
            <li class="hide litab2"><a href="#tab2">6+ Months <span>(0)</span></a></li>
            <li class="hide litab3"><a href="#tab3">Managers <span>(0)</span></a></li>
            <li class="hide litab4"><a href="#tab4">Training Managers <span>(0)</span></a></li>

        </ul>
        <div class="tab_container">
            <div id="tab1" class="tab_content">
                </div>
            <div id="tab2" class="tab_content">
                </div>
            <div id="tab3" class="tab_content">
                
            </div>
            <div id="tab4" class="tab_content">
                 </div>
            <div id="tab5" class="tab_content">
               </div>
        </div>
    </div>



    <?php
}
