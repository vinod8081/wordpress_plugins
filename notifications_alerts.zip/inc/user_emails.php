<?php

/**
 * Get the html for listing the email ids
 * @param type $final_array
 * @param type $group_ids
 * @return string
 */
function build_html($final_array, $group_ids) {
    $html = '';
    $html .='<div style="clear:both;"></div>';
    foreach ($final_array as $key => $value) {
        $html .= '<div class="each_email">
                    <div style="width: 10%; float: left;">
                        <input type="checkbox" class="checkboxesall checkbox_' . $group_ids . '" name="each_mail[]" value="' . $key . '"/>
                    </div>
                    <div class="first_lastname">' . $value . '</div>
                </div>';
    }
    $html .='<div style="clear:both;"></div>';
    return $html;
}

/**
 * Get the all the email ids by applying filter on groups
 * @global type $post
 * @global type $wpdb
 */
function get_user_email_ids() {

    //***********************// Step 1************************************************************
    // Using post id find the group access
    global $post, $wpdb;
    $ID = $_POST['post_id'];
    error_log("post_id=" . $ID);
    $table1 = $wpdb->prefix . 'uam_accessgroup_to_object';
    $table2 = $wpdb->prefix . 'users';
    $table3 = $wpdb->prefix . 'uam_accessgroups';
    $result1 = $wpdb->get_results(
            "SELECT group_id"
            . " FROM {$table1}"
            . " WHERE object_id = {$ID} "
            . " AND object_type= 'page'"
    );
    //error_log("Last query1=" . $wpdb->last_query);
    $selectAllhtml = '';
    /* '<div style="width: 50%; float: left;">
      <div style="width: 10%; float: left;">
      <input type="checkbox" class="selectall" />
      </div>
      <div style="width: 90%;">Select All Groups</div>
      </div>'; */

    $html = '';
    $response = array();
    foreach ($result1 as $eachrow) {
        $group_ids = $eachrow->group_id;
        //***********************// Step 2************************************************************
        //Get all the users have group ids with details like email nicename


        $result2 = $wpdb->get_results(
                "SELECT  u.user_email AS email, u.display_name as name, u.user_nicename as name2"
                . " FROM {$table1} as uam"
                . " LEFT JOIN {$table2} as u ON(uam.object_id = u.ID)"
                . " WHERE uam.group_id = ({$group_ids})"
                . " AND uam.object_type='user'"
                . "group by u.display_name ASC"
        );
        //error_log("Last query2=" . $wpdb->last_query);
        $email_array = array();
        foreach ($result2 as $each_user) {
            $email = strtolower(trim($each_user->email));
            $name = trim($each_user->name);
            $name = strlen($name) < 1 ? trim($each_user->name2) : $name;
            $name = ucwords($name);
            if ($email != '')
                $email_array[$email] = $name;
        }
        $accessgroup = $wpdb->get_var(
                "SELECT groupname"
                . " FROM {$table3}"
                . " WHERE id = {$group_ids} "
        );


        /* $html .= '<div style="width: 50%; float: left;">
          <div style="width: 90%;">User with access as "'.$accessgroup.'"</div>
          </div>'; */


        $html .='<div style="clear:both;"></div>';
        $html .='<div>';
        $html .= '<div class="select_all" >
                    <input type="checkbox" class="selectall_' . $group_ids . '" /> Select All
                </div>';

        $html .= build_html($email_array, $group_ids);
        $html .='</div>';
        $response[$accessgroup] = $html;
        $html = '';
    }
    if (!empty($response)) {
        echo json_encode(array('result' => $response));
        die;
    } else {
        echo json_encode(array('result' => 'empty'));
        die;
    }
}

add_action('wp_ajax_nopriv_getuseremailids', 'get_user_email_ids');
add_action('wp_ajax_getuseremailids', 'get_user_email_ids');
?>
