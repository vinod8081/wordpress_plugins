<?php

/*
  Plugin Name: Notifications Alerts
  Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
  Description: whenever we have new content on Barton Academy, I have to send out an email to our 200+ end users notifying them of the updates. We currently do not have the ability to allow users to see when new content is added to Barton Academy. I would like the ability to send alerts or notifications to the end users that new content, or changes have been made to the webpage. Generally the content that is uploaded is catered towards all of our sales and recruiting employees, however there is content that is uploaded that is role specific (recruiter or account manager) and is different based on their employment tenure (ex: 0-6 months, 6+ months, manager training).
  Version: 1.0
  Author: Vinod Pawar
  Author URI: http://URI_Of_The_Plugin_Author
  License: GPL
 */

//SETUP
function notifications_alerts_plugin_install()
{
    if (version_compare(get_bloginfo('version'), '3.1', '<'))
    {
        wp_die("You must update WordPress to use this plugin!");
    }
    global $wpdb;

    $sql = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}article_notifications_alerts`"
            . " (`id` int(11) NOT NULL AUTO_INCREMENT,"
            . "`article_id` int(11) NOT NULL,"
            . "`article_link` tinytext NOT NULL,"
            . "`mail_list` text NOT NULL,"
            . "`send_mail_status` tinyint(4) NOT NULL DEFAULT '0',"
            . "`total_send_mail` tinyint(4) NOT NULL DEFAULT '0',"
            . "`created_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',"
            . "`updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
            . "PRIMARY KEY (`id`)"
            . ") "
            . "ENGINE=InnoDB";

    $wpdb->query($sql);
}

register_activation_hook(__FILE__, 'notifications_alerts_plugin_install');

//Uninstall
function notifications_alerts_plugin_unistall()
{
    global $wpdb;
    $sql = "drop TABLE {$wpdb->prefix}article_notifications_alerts;";
    $wpdb->query($sql);
}

register_deactivation_hook(__FILE__, 'notifications_alerts_plugin_unistall');

/**
 * Get the javascript file
 */
function notifications_alerts_enqueue_scripts()
{
    wp_register_script('notifications_alerts_js', plugin_dir_url(__FILE__) . 'js/notifications_alerts.js', array(), false, true);
    wp_enqueue_script('notifications_alerts_js');
}
add_action('admin_enqueue_scripts', 'notifications_alerts_enqueue_scripts');
/**
 * Get the css file at top
 */
function notifications_alerts_load_css_js_at_top()
{   
    echo '<link href="' . plugin_dir_url(__FILE__) . 'css/notifications_alerts.css" rel="stylesheet" type="text/css" />';
}
add_action('admin_head', 'notifications_alerts_load_css_js_at_top', 1);

// inclued file
include 'view/display.php';
include 'inc/user_emails.php';

/**
 * Saves the custom meta input
 */
function notifications_alerts_meta_save($post_id)
{
    global $wpdb;

    // Checks save status
    $is_autosave    = wp_is_post_autosave($post_id);
    $is_revision    = wp_is_post_revision($post_id);
    $is_valid_nonce = ( isset($_POST['notifications_alerts_nonce']) && wp_verify_nonce($_POST['notifications_alerts_nonce'], 'notifications_alerts_add_meta_box') ) ? 'true' : 'false';


    // Exits script depending on save status
    if ($is_autosave || $is_revision || !$is_valid_nonce)
    {

        return;
    }


    // Checks for input and sanitizes/saves if needed
    if (isset($_POST['send_mail_to_users']) && $_POST['send_mail_to_users'] == 1)
    {

        $email_ids = $_POST['each_mail'];
        $post_id   = $_POST['post_id'];

        $mail_list    = implode(',', $email_ids);
        $article_link = get_permalink($post_id);
        $created_on   = date('Y-m-d H:i:s');

        $data = array(
            'article_id'   => $post_id,
            'article_link' => $article_link,
            'mail_list'    => $mail_list,
            'created_on'   => $created_on
        );

        $your_tbl_name = "{$wpdb->prefix}article_notifications_alerts";
        if (!$wpdb->insert($your_tbl_name, $data))
        {
            error_log('Error while inserting mail list for article ' . $article_link);
        }
        else
        {
            echo "\n Successfuly inserted mail list for article " . $article_link;
        }
        return;
    }
    
}

add_action('save_post', 'notifications_alerts_meta_save');

/**
 * Load javascript at the bottom
 */
function load_na_js_at_top()
{    
    $admin_url = admin_url('admin-ajax.php');
    echo "<script>var ajaxurl='{$admin_url}'; </script>";    
}
add_action('wp_head', 'load_na_js_at_top', 1);
/*
  // load intial setup
  function notifications_alerts_plugin_init()
  {
  //do work
  notifications_alerts_run_sub_process();
  }

  //HOOKS
  add_action('init', 'notifications_alerts_plugin_init');

  function notifications_alerts_run_sub_process()
  {

  }
 */
?>