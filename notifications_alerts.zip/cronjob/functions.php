<?php
/**
 * Get the mails ids from database
 * @global type $wpdb
 * @return type
 */
function get_notifications_alerts_record_from_db()
{
    global $wpdb;

    $your_tbl_name = $wpdb->prefix . 'article_notifications_alerts';
    $mail_details  = $wpdb->get_results(
            "SELECT id, article_id,article_link,mail_list"
            . " FROM {$your_tbl_name}"
            . " WHERE send_mail_status = 0 "
            . " LIMIT 1"
    );
    return $mail_details;
}
/**
 * Update status for send mail
 * @global type $wpdb
 * @param type $row_id
 * @return type
 */
function update_notifications_alerts_record_in_db($row_id)
{
    global $wpdb;
    $your_tbl_name = $wpdb->prefix . 'article_notifications_alerts';
    $mail_details  = $wpdb->update($your_tbl_name, array(
        'send_mail_status' => 1,
        'updated_on'=>date('Y-m-d H:i:s')
            ), array('id' => $row_id)
    );
    return $mail_details;
}
