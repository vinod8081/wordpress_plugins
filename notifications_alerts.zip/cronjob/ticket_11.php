<?php

/* * ************************************************************************************************************* */
/**
 * Added code to send notifications_alerts through mail. Sending updated article link to the user
 * We are running cron for every 5 mintues.  
 * By VP
 * https://barton.atlassian.net/browse/ACADEMY-11
 */
// Include the wp-load'er

if (file_exists('../../../../wp-load.php')) {
        require_once '../../../../wp-load.php';
} elseif(file_exists('/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php')) {
    require_once '/var/www/vhosts/qhss-vswk.accessdomain.com/httpdocs/bartonacademy.com/wp-load.php';
}

include 'functions.php';


/**
 * Get the message for sending the mails
 * @param type $title
 * @param type $permalink
 * @return type
 */
function get_message($title, $permalink){
    return '<!DOCTYPE html><html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>Barton Academy</title>
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" width="480" style="border:1px solid #14518a;padding:15px; line-height:15px;font-family:arial;font-size:13px">
            <tbody>
                <tr border="0">                      
                    <td width="351" height="49" border="0">&nbsp;
                    </td>    
                    <td width="149" height="49" border="0">
                        <img src="'.  site_url().'/wp-content/uploads/2013/04/ba-logo.jpg" />
                    </td>
                </tr>
                <tr>                      
                    <td colspan="2" border="0">
                        <p>Hi,<br><br>
                            The following training material has been added to Barton Academy. For your reference, the links for this material are located below. The material is also available in the “'. $title .'” Tab. <br/><br/> '.$permalink.' <br/><br/>
                            I hope this information is helpful to you. If you have any feedback, questions, or have any recommendations for future updates, please feel free to bring it to my attention as we will continue to evolve the site.<br><br>

                            Thank you,<br/>
                            Steve</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>';
}
/**
 * Send the mails for each user about the notification
 * @return boolean
 */
function send_mail_for_article_notifications_alerts()
{

    //***********************// Step 1************************************************************    
    //get the mail ids from db
    $mail_details = get_notifications_alerts_record_from_db();
    if (!count($mail_details))
    {
        echo '\nUpdated articles are not found for the day ' . date('Y-m-d H:i:s');
        return;
    }
    $post_id   = $mail_details[0]->article_id;
    $permalink = $mail_details[0]->article_link;
    $mail_list = $mail_details[0]->mail_list;
    $row_id = $mail_details[0]->id;

    
    $title = get_the_title( $post_id );    
    $subject = sprintf('Published: %s', $title);
    
    /*function for getting html template when article update*/
   $message = get_message($title, $permalink);
    ///$headers[] = '';
    //***********************// Step 4************************************************************
    //send the email for each individual user

    $headers[] = "From: Barton Academy <academyadmin@bartonassociates.com>";
    //$headers[] = "Cc: Yasmeen Sayyed <Yasmeen.Sayyed@silicus.com>";
    $headers[] = "Bcc: vinod pawar <vinod.pawar@silicus.com>";
    $mail      = 1;
    $mail_list = explode(',', $mail_list);
    foreach ($mail_list as $each_user)
    {
        $name  = '';
        //$email = $each_user->email;
        //$email = 'Yasmeen.Sayyed@silicus.com';
        $email = 'vinod.pawar@silicus.com';
        $to    = sprintf('%s <%s>', $name, $email);
        
        echo '\n Mail send successfully to '.$email;
        wp_mail(strtolower($to), $subject, $message, $headers);
        $mail++;
        break;
    }
    error_log('Total Send mail=' . $mail);
    
    
    $mail_details = update_notifications_alerts_record_in_db($row_id);
    
    return true;
}
send_mail_for_article_notifications_alerts();
