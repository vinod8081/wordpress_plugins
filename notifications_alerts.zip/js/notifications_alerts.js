(function ($) {

    jQuery('input[type=radio][name=send_mail_to_users]').on('change', function () {

        switch ($(this).val()) {
            case '1' :

                $("#notifications_alerts_email_list").html('<div class="div_loading"></div>');

                /* send ajax request to get the user list */
                jQuery.ajax({
                    url: ajaxurl, /* this is the object instantiated in wp_localize_script function */
                    type: "POST",
                    data: {
                        action: 'getuseremailids',
                        post_id: $('#post_id').val()
                    },
                    success: function (data) {
                        //console.log(data);
                        $("#notifications_alerts_email_list").html('');
                        $("ul.tabs, div.tab_container").removeClass("hide");
                        var obj = $.parseJSON(data);
                        if (obj.result == 'empty') {
                            $("#notifications_alerts_email_list").html('No Result.');
                        } else {
                            $('#notifications_alerts_div').show();
                            var active_tab = '';
                            $.each(obj.result, function (item, value) {
                                //console.log(item);
                                //console.log(value);
                                if (item == '0-6 Months') {
                                    $("#tab1").html(value);
                                    $("li.litab1").removeClass("hide");
                                    active_tab = 'litab1';
                                }
                                if (item == '6+ Months') {
                                    $("#tab2").html(value);
                                    $("li.litab2").removeClass("hide");
                                }
                                if (item == 'Managers') {
                                    $("#tab3").html(value);
                                    $("li.litab3").removeClass("hide");
                                }
                                if (item == 'Training Managers') {
                                    $("#tab4").html(value);
                                    $("li.litab4").removeClass("hide");
                                }

                            });
                            var tab = 1;
                            $('div.tab_container').children('div').each(function () {
                                if ($(this).find('div').length) {
                                    $('ul.tabs li.litab' + tab).trigger('click');
                                    return false;
                                }
                                tab++;
                            });
                        }
                        return;
                    }, error: function (errorThrown) {
                        //alert(errorThrown);
                    }
                });

                break;
            case '0' :
                $("#notifications_alerts_email_list").html('');
                $("ul.tabs, div.tab_container, li.litab1, li.litab2, li.litab3, li.litab4").addClass("hide");
                $("#tab1,#tab2,#tab3,#tab4").html('');
                $('ul.tabs li span').html(' (0)');
                break;
        }
    });
    /**
     * Click on tab
     */
    $("ul.tabs li").on('click', function () {

        $("ul.tabs li").removeClass("active"); //Remove any "active" class
        $(this).addClass("active"); //Add "active" class to selected tab
        $(".tab_content").hide(); //Hide all tab content
        var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
        $(activeTab).fadeIn(); //Fade in the active content
        return false;
    });
    /**
     * If selected the select all for 0-6 Months
     */
    $("body").on("click", ".selectall_1", function () {

        if (this.checked) {
            $('.checkbox_1').each(function () {
                this.checked = true;
            });
            $('ul.tabs li.active span').html(' (' + $('.checkbox_1').length + ')');

        } else {
            $('.checkbox_1').each(function () {
                this.checked = false;
            });
            $('ul.tabs li.active span').html(' (0)');
        }
    });

    $("body").on("click", ".selectall", function () {
        if (this.checked) {
            $('.checkboxesall').each(function () {
                this.checked = true;
            });
            if ($('.selectall_1').length)
                $('.selectall_1')[0].checked = true;
            if ($('.selectall_2').length)
                $('.selectall_2')[0].checked = true;
            if ($('.selectall_3').length)
                $('.selectall_3')[0].checked = true;
            if ($('.selectall_4').length)
                $('.selectall_4')[0].checked = true;
        } else {
            $('.checkboxesall').each(function () {
                this.checked = false;
            });
            if ($('.selectall_1').length)
                $('.selectall_1')[0].checked = false;
            if ($('.selectall_2').length)
                $('.selectall_2')[0].checked = false;
            if ($('.selectall_3').length)
                $('.selectall_3')[0].checked = false;
            if ($('.selectall_4').length)
                $('.selectall_4')[0].checked = false;
        }
    });

    $("body").on("click", ".checkbox_1", function () {

        $('ul.tabs li.active span').html(' (' + $(".checkbox_1:checked").length + ')');
    });

    /**
     * If selected the select all for 6+ Months
     */
    $("body").on("click", ".selectall_2", function () {
        if (this.checked) {
            $('.checkbox_2').each(function () {
                this.checked = true;
            });
            $('ul.tabs li.active span').html(' (' + $('.checkbox_2').length + ')');
        } else {
            $('.checkbox_2').each(function () {
                this.checked = false;
            });
            $('ul.tabs li.active span').html(' (0)');
        }
    });
    $("body").on("click", ".checkbox_2", function () {

        $('ul.tabs li.active span').html(' (' + $(".checkbox_2:checked").length + ')');
    });
    /**
     * If selected the select all for 3rd tab
     */
    $("body").on("click", ".selectall_3", function () {

        if (this.checked) {
            $('.checkbox_3').each(function () {
                this.checked = true;
            });
            $('ul.tabs li.active span').html(' (' + $('.checkbox_3').length + ')');
        } else {
            $('.checkbox_3').each(function () {
                this.checked = false;
            });
            $('ul.tabs li.active span').html(' (0)');
        }
    });
    $("body").on("click", ".checkbox_3", function () {

        $('ul.tabs li.active span').html(' (' + $(".checkbox_3:checked").length + ')');
    });
    /**
     * If selected the select all for 4th tab
     */
    $("body").on("click", ".selectall_4", function () {

        if (this.checked) {
            $('.checkbox_4').each(function () {
                this.checked = true;
            });
            $('ul.tabs li.active span').html(' (' + $('.checkbox_4').length + ')');
        } else {
            $('.checkbox_4').each(function () {
                this.checked = false;
            });
            $('ul.tabs li.active span').html(' (0)');
        }
    });
    $("body").on("click", ".checkbox_4", function () {

        $('ul.tabs li.active span').html(' (' + $(".checkbox_4:checked").length + ')');
    });
})(jQuery);